Playbook Directory contains all the Ansible Playbook created in this lab.
