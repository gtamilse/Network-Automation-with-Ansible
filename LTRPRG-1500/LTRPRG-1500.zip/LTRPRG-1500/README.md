# Cisco Live 2019 TECDEV-1500 

## Network Automation with Ansible

### Session 1 - 30 attendees

Presenters Gowtham Tamilselvan, Muthuraja Ayyanar, & Yogi Raghunathan

June 10, 2019

Directory for Ansible lab


