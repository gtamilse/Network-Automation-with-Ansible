# **<p align="center">Network Automation with Ansible</p>**
---
# **<p align="center">Lab Startup File</p>**

---
### **<p align="center">Gowtham Tamilselvan | Muthuraja Ayyanar | Yogi Raghunathan </p>**
### **<p align="center">June 10 2019</p>**

---
# [Lab pod assignment](./LTRPRG-1500-Pod-Assignment.md)
# [Lab access](./lab-access.md)
# [Lab guide](./Network-Automation-with-Ansible.md)
# [Lecture Slides](./LTRPRG-1500-Network-Automation-with-Ansible.pdf)
# [Playbook files](./playbooks)
# [VI reference](./vi-reference.md)

---
